"""Check RRBot feedback after sending a position command or trajectory."""

import argparse
import math
import time

import rclpy
from builtin_interfaces.msg import Duration
from controller_manager_msgs.srv import ListControllers
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("forward", "trajectory"), default="forward")
    parser.add_argument("--positions", nargs=2, type=float, default=[0.5, -0.5])
    parser.add_argument("--timeout", type=float, default=90.0)
    args = parser.parse_args()
    if not all(math.isfinite(value) for value in args.positions):
        parser.error("positions must be finite")
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error("timeout must be positive and finite")

    rclpy.init()
    node = Node("rrbot_motion_check")
    latest = {}

    def receive(message):
        latest.update(zip(message.name, message.position))

    subscription = node.create_subscription(JointState, "/joint_states", receive, 10)
    if args.mode == "forward":
        publisher = node.create_publisher(
            Float64MultiArray, "/forward_position_controller/commands", 10
        )
        message = Float64MultiArray(data=args.positions)
    else:
        publisher = node.create_publisher(
            JointTrajectory, "/joint_trajectory_position_controller/joint_trajectory", 10
        )
        message = JointTrajectory(
            joint_names=["joint1", "joint2"],
            points=[JointTrajectoryPoint(
                positions=args.positions, time_from_start=Duration(sec=2)
            )],
        )

    try:
        controller_name = (
            "forward_position_controller" if args.mode == "forward"
            else "joint_trajectory_position_controller"
        )
        client = node.create_client(ListControllers, "/controller_manager/list_controllers")
        if not client.wait_for_service(timeout_sec=30):
            raise RuntimeError("Controller Manager service was not discovered")
        deadline = time.monotonic() + 30
        while True:
            future = client.call_async(ListControllers.Request())
            rclpy.spin_until_future_complete(node, future, timeout_sec=2)
            if future.done() and future.result() is not None and any(
                controller.name == controller_name and controller.state == "active"
                for controller in future.result().controller
            ):
                break
            if time.monotonic() >= deadline:
                raise RuntimeError(f"Controller did not become active: {controller_name}")
            time.sleep(0.1)

        deadline = time.monotonic() + 15
        while publisher.get_subscription_count() == 0:
            if time.monotonic() >= deadline:
                raise RuntimeError("Controller command subscriber was not discovered")
            rclpy.spin_once(node, timeout_sec=0.1)

        latest.clear()
        publisher.publish(message)
        deadline = time.monotonic() + args.timeout
        while time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
            actual = [latest.get("joint1"), latest.get("joint2")]
            if all(value is not None and math.isfinite(value) and abs(value - target) < 0.02
                   for value, target in zip(actual, args.positions)):
                print(f"PASS {args.mode}: target={args.positions}, feedback={actual}")
                return
        raise RuntimeError(f"Target was not reached; latest feedback: {latest}")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
