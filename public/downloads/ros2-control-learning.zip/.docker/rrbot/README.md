# RRBot Example 1：Docker 无界面实战

在仓库根目录执行以下命令。需要先启动 Docker Desktop。

```bash
python3 .docker/rrbot/prepare_sources.py
docker compose -f .docker/rrbot/compose.yaml up -d --build
docker compose -f .docker/rrbot/compose.yaml logs -f
```

默认复用本机已有的 ARM64 `ros2-jazzy-learning:dev` 基础镜像。
在没有此镜像的机器上，可以设置 `ROS_BASE_IMAGE=ros:jazzy-ros-base` 再执行构建命令。

`prepare_sources.py` 按文件拉取必需的官方源码，校验 Git blob 哈希后保存为本地归档。
归档缓存在 `source-archives/` 并被 Git 忽略，后续构建可以重复使用。

镜像使用 ROS 2 Jazzy，编译当前仓库源码和 Jazzy 分支的配套依赖、
RRBot Example 1、位置转发控制器、关节状态广播器及轨迹控制器。
启动参数为 `gui:=false`，不启动 RViz。

## 进入 ROS 终端

```bash
docker compose -f .docker/rrbot/compose.yaml exec rrbot /rrbot-entrypoint.sh bash
```

下面的命令在这个容器终端执行：

```bash
ros2 control list_controllers
ros2 control list_hardware_interfaces
ros2 topic echo /joint_states
```

按 Ctrl+C 停止 topic echo 后，发送位置指令：

```bash
ros2 topic pub --once /forward_position_controller/commands \
  std_msgs/msg/Float64MultiArray '{data: [0.5, -0.5]}'
ros2 topic echo /joint_states --once
```

自动等待反馈到达目标（容差 0.02 rad，默认最多等待 90 秒）：

```bash
python3 /ws/src/ros2_control/.docker/rrbot/check_motion.py
```

原版示例的默认模拟响应较慢，接近目标可能需要几十秒。
验证脚本通过只读挂载使用本机版本，修改等待时间后无需重新构建镜像。

## 切换到轨迹控制器

首次使用时加载并配置轨迹控制器。如果 `ros2 control list_controllers` 已列出该控制器，
可跳过加载步骤。

```bash
ros2 control load_controller joint_trajectory_position_controller \
  "$(ros2 pkg prefix --share ros2_control_demo_example_1)/config/rrbot_jtc.yaml" \
  --set-state inactive
```

切换控制器并验证两秒轨迹：

```bash
ros2 control switch_controllers \
  --deactivate forward_position_controller \
  --activate joint_trajectory_position_controller --strict
python3 /ws/src/ros2_control/.docker/rrbot/check_motion.py \
  --mode trajectory --positions -0.3 0.3
```

切回位置转发控制器并回零：

```bash
ros2 control switch_controllers \
  --deactivate joint_trajectory_position_controller \
  --activate forward_position_controller --strict
python3 /ws/src/ros2_control/.docker/rrbot/check_motion.py --positions 0 0
```

## 停止、重启和源码修改

在 Mac 的仓库根目录执行：

```bash
docker compose -f .docker/rrbot/compose.yaml stop
docker compose -f .docker/rrbot/compose.yaml up -d
```

源码在构建时复制到镜像中，修改本地源码后需重新运行 `up -d --build`。
容器重启后重新加载默认控制器；手动加载的轨迹控制器需要再次加载。

本示例使用 RRBot 自己的模拟硬件插件。若要研究 `mock_components/GenericSystem`，
需要另外修改 URDF 的硬件插件声明；两者实现不相同。
