"""Cache verified Jazzy source files without requiring a large Git transfer."""

import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import tarfile
import tempfile
import time
import urllib.request


REPOSITORIES = {
    "ros2_control_demos": {
        "example_1", "ros2_control_demo_description", "ros2_control_demo_test_utils"
    },
    "ros2_controllers": {
        "forward_command_controller", "joint_state_broadcaster",
        "joint_trajectory_controller", "ros2_controllers_test_nodes"
    },
    "realtime_tools": None,
    "control_msgs": None,
    "ros2_control_cmake": None,
}


def fetch(url):
    for attempt in range(4):
        try:
            with urllib.request.urlopen(url, timeout=25) as response:
                return response.read()
        except Exception:
            if attempt == 3:
                raise
            time.sleep(attempt + 1)


def prepare(repo, directories, cache):
    target = cache / (repo + ".tar.gz")
    if target.exists():
        with tarfile.open(target) as archive:
            archive.getmembers()
        print(f"Using cache: {repo}", flush=True)
        return
    commit = json.loads(fetch(
        f"https://api.github.com/repos/ros-controls/{repo}/git/ref/heads/jazzy"
    ))["object"]["sha"]
    tree = json.loads(fetch(
        f"https://api.github.com/repos/ros-controls/{repo}/git/trees/{commit}?recursive=1"
    ))
    if tree.get("truncated"):
        raise RuntimeError(f"Incomplete upstream tree: {repo}")
    files = [item for item in tree["tree"] if item["type"] == "blob" and (
        directories is None or item["path"].split("/")[0] in directories
        or item["path"] in {"LICENSE", "LICENSE.txt"}
    )]
    print(f"Fetching {repo}: {len(files)} files, commit {commit[:12]}", flush=True)
    with tempfile.TemporaryDirectory(prefix="rrbot-sources-") as temporary:
        root = Path(temporary) / repo
        root.mkdir()

        def download(item):
            path = item["path"]
            data = fetch(f"https://raw.githubusercontent.com/ros-controls/{repo}/{commit}/{path}")
            digest = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            if digest != item["sha"]:
                raise RuntimeError(f"Upstream file hash mismatch: {repo}/{path}")
            destination = root / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            if item["mode"] == "120000":
                destination.symlink_to(data.decode())
            else:
                destination.write_bytes(data)
                if item["mode"] == "100755":
                    destination.chmod(0o755)

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            for index, _ in enumerate(pool.map(download, files), 1):
                if index % 40 == 0:
                    print(f"  {repo}: {index}/{len(files)}", flush=True)
        (root / ".rrbot-upstream.json").write_text(json.dumps({
            "repository": f"https://github.com/ros-controls/{repo}", "commit": commit,
            "branch": "jazzy", "file_count": len(files),
        }, indent=2) + "\n")
        partial = target.with_suffix(".partial")
        with tarfile.open(partial, "w:gz") as archive:
            archive.add(root, arcname=repo)
        os.replace(partial, target)
    print(f"Verified archive ready: {repo}", flush=True)


if __name__ == "__main__":
    cache = Path(__file__).resolve().parent / "source-archives"
    cache.mkdir(exist_ok=True)
    for repository, selected_directories in REPOSITORIES.items():
        prepare(repository, selected_directories, cache)
